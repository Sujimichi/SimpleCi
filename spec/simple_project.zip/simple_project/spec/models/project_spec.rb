require 'spec_helper'

describe "something" do 

  it 'should have a test which passes' do 
    true.should be_true
  end

  it 'should have a test which fails' do 
    false.should be_true
  end

end
