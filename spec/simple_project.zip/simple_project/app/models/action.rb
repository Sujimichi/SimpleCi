class Action < ActiveRecord::Base
  belongs_to :project

  def run
  end
end
