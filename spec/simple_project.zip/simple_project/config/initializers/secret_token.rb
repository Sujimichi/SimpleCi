# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
SimpleCi::Application.config.secret_token = '63d5f37068cbe4df9a084ce6bc6bc7f493df5fb0b070d9da6c0ab815f80b96578dc1ddd00f5751fb79c720de5dad131d21fb421bd11528490e246961527949b1'
